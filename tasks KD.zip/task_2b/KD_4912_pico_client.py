#!/usr/bin/env python3

import time

import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node

from waypoint_navigation.action import NavToWaypoint
from waypoint_navigation.srv import GetWaypoints


class WayPointClient(Node):

    def __init__(self):
        super().__init__('waypoint_client')
        self.goals = []
        self.goal_index = 0
        self.total_time = 0

        # Action client for the custom NavToWaypoint action.
        self.action_client = ActionClient(
            self, NavToWaypoint, 'waypoint_navigation')

        # Service client used to fetch the predefined rescue route.
        self.cli = self.create_client(GetWaypoints, 'waypoints')

        while not self.cli.service_is_ready() and rclpy.ok():
            self.get_logger().info('service not available, waiting again...')
            rclpy.spin_once(self, timeout_sec=0.5)

        self.req = GetWaypoints.Request()
        self.req.get_waypoints = True

        self.get_logger().info('Waypoint client ready')

    # ------------------------------------------------------------------
    # Action client functions
    # ------------------------------------------------------------------
    def send_goal(self, waypoint):

        goal_msg = NavToWaypoint.Goal()
        goal_msg.waypoint.position.x = float(waypoint[0])
        goal_msg.waypoint.position.y = float(waypoint[1])
        goal_msg.waypoint.position.z = float(waypoint[2])
        goal_msg.waypoint.orientation.w = 1.0
        goal_msg.hover = True

        # Wait for the action server without blocking discovery.  On the very
        # first goal this spins until the server is up; afterwards the server
        # is already ready and this returns immediately.
        while not self.action_client.server_is_ready() and rclpy.ok():
            self.get_logger().info('action server not available, waiting...')
            rclpy.spin_once(self, timeout_sec=0.5)

        self.get_logger().info(
            'Sending goal %d/%d: [%.2f, %.2f, %.2f]' % (
                self.goal_index + 1, len(self.goals),
                waypoint[0], waypoint[1], waypoint[2]))

        self.send_goal_future = self.action_client.send_goal_async(
            goal_msg, feedback_callback=self.feedback_callback)
        self.send_goal_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):

        goal_handle = future.result()
        if goal_handle is None or not goal_handle.accepted:
            self.get_logger().info('Goal rejected by the action server')
            return

        self.get_logger().info('Goal accepted by the action server')
        self.get_result_future = goal_handle.get_result_async()
        self.get_result_future.add_done_callback(self.get_result_callback)

    def get_result_callback(self, future):

        result = future.result().result
        self.get_logger().info(
            'Result: settled in {0} s'.format(result.hov_time))

        self.total_time += max(0, result.hov_time)
        self.get_logger().info(
            'Accumulated settle time: %d s' % self.total_time)

        self.goal_index += 1

        if self.goal_index < len(self.goals):
            self.send_goal(self.goals[self.goal_index])
        else:
            self.get_logger().info(
                'All waypoints have been reached successfully')

    def feedback_callback(self, feedback_msg):

        feedback = feedback_msg.feedback
        x = feedback.current_waypoint.pose.position.x
        y = feedback.current_waypoint.pose.position.y
        z = feedback.current_waypoint.pose.position.z
        t = feedback.current_waypoint.header.stamp.sec
        self.get_logger().info(
            'Received feedback! The current whycon position is: '
            '%.3f, %.3f, %.3f' % (x, y, z))
        self.get_logger().info('Max time inside sphere: %d' % t)

    # ------------------------------------------------------------------
    # Service client functions
    # ------------------------------------------------------------------
    def send_request(self):
        return self.cli.call_async(self.req)

    def receive_goals(self):
        future = self.send_request()
        rclpy.spin_until_future_complete(self, future)

        response = future.result()
        if response is None:
            self.get_logger().error('Failed to receive waypoints')
            return

        self.get_logger().info('Waypoints received by the action client')

        if len(response.marker_ids) == len(response.waypoints.poses):
            for marker_id in response.marker_ids:
                self.get_logger().info('Marker id: %s' % marker_id)

        for pose in response.waypoints.poses:
            waypoints = [pose.position.x, pose.position.y, pose.position.z]
            self.goals.append(waypoints)
            self.get_logger().info(f'Waypoints: {waypoints}')

        if not self.goals:
            self.get_logger().error('No waypoints returned by the service')
            return

        self.send_goal(self.goals[0])


def main(args=None):
    rclpy.init(args=args)

    waypoint_client = WayPointClient()
    waypoint_client.receive_goals()

    try:
        rclpy.spin(waypoint_client)
    except KeyboardInterrupt:
        waypoint_client.get_logger().info('KeyboardInterrupt, shutting down.\n')
    finally:
        waypoint_client.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()

