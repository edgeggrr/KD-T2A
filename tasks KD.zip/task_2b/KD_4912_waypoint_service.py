#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose
from waypoint_navigation.srv import GetWaypoints


class WayPoints(Node):

    def __init__(self):
        super().__init__('waypoints_service')

        # Predefined rescue route, in the exact order the drone must fly it.
        # WhyCode frame units (x, y, z).
        self.waypoints = [
            [-2.41, -2.41, 13.00],   # wp1
            [2.41, 1.20, 13.00],     # wp2
            [1.20, -2.41, 13.00],    # wp3
            [-1.20, 1.20, 13.00],    # wp4
        ]
        self.marker_ids = ['wp1', 'wp2', 'wp3', 'wp4']

        self.srv = self.create_service(
            GetWaypoints, 'waypoints', self.waypoint_callback)

        self.get_logger().info(
            'Waypoint service ready with %d waypoints' % len(self.waypoints))

    def waypoint_callback(self, request, response):

        if request.get_waypoints:
            response.waypoints.poses = [Pose() for _ in range(len(self.waypoints))]
            response.waypoints.header.stamp = self.get_clock().now().to_msg()
            response.waypoints.header.frame_id = 'whycode'
            response.marker_ids = list(self.marker_ids)
            for i in range(len(self.waypoints)):
                response.waypoints.poses[i].position.x = self.waypoints[i][0]
                response.waypoints.poses[i].position.y = self.waypoints[i][1]
                response.waypoints.poses[i].position.z = self.waypoints[i][2]
                response.waypoints.poses[i].orientation.w = 1.0
            self.get_logger().info("Incoming request for Waypoints")
            return response

        else:
            self.get_logger().info("Request rejected")
            return response


def main():
    rclpy.init()
    waypoints = WayPoints()

    try:
        rclpy.spin(waypoints)
    except KeyboardInterrupt:
        waypoints.get_logger().info('KeyboardInterrupt, shutting down.\n')
    finally:
        waypoints.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()

