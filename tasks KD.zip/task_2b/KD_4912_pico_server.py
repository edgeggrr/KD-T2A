#!/usr/bin/env python3

# ROS 2 action server that flies the Swift Pico to a sequence of waypoints.
# The position controller is the same PID controller used for Task 2A; it is
# embedded here so the action server can command the drone directly.

import math
import threading
import time

import rclpy
from rclpy.action import ActionServer, CancelResponse, GoalResponse
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node

from waypoint_navigation.action import NavToWaypoint

from swift_msgs.msg import SwiftMsgs
from std_msgs.msg import Header
from whycode_interfaces.msg import MarkerArray
from error_msg.msg import Error
from controller_msg.msg import PIDTune


BASE_RC = 1500.0


def _clamp(value, low, high):
    return max(low, min(high, value))


def _slew(current, target, max_step):
    if target > current:
        return min(target, current + max_step)
    return max(target, current - max_step)


class WayPointServer(Node):

    def __init__(self):
        super().__init__('waypoint_server')

        self.pid_or_lqr_callback_group = ReentrantCallbackGroup()
        self.action_callback_group = ReentrantCallbackGroup()

        # --- action / settling state ---------------------------------
        self.state_lock = threading.Lock()
        self.hold_time = float(self.declare_parameter(
            'hold_time', 3.0).value)
        self.whycode_tolerance = float(self.declare_parameter(
            'whycode_tolerance', 0.4).value)
        self.goal_timeout = float(self.declare_parameter(
            'goal_timeout', 25.0).value)

        # --- controller configuration --------------------------------
        self.sample_time = 1.0 / 30.0
        self.airborne_z_start = float(self.declare_parameter(
            'airborne_z_start', 14.6).value)
        self.airborne_z_full = float(self.declare_parameter(
            'airborne_z_full', 14.2).value)
        self.marker_timeout = float(self.declare_parameter(
            'marker_timeout', 0.5).value)

        self.max_tilt = float(self.declare_parameter(
            'max_tilt_counts', 80.0).value)
        self.throttle_min = int(self.declare_parameter(
            'throttle_min', 1400).value)
        self.throttle_max = int(self.declare_parameter(
            'throttle_max', 1600).value)
        self.hover_throttle = float(self.declare_parameter(
            'hover_throttle', 1500).value)
        self.altitude_ceiling_margin = float(self.declare_parameter(
            'altitude_ceiling_margin', 0.4).value)

        self.max_tilt_step = float(self.declare_parameter(
            'max_tilt_step', 5.0).value)
        self.max_throttle_step = float(self.declare_parameter(
            'max_throttle_step', 15.0).value)

        self.integral_limit = float(self.declare_parameter(
            'integral_limit', 8.0).value)

        # Horizontal gain scheduling: relax damping during the long transit
        # and increase it close to the waypoint so the drone brakes hard and
        # does not overshoot.
        self.brake_radius = float(self.declare_parameter(
            'brake_radius', 2.0).value)
        self.kd_far_scale = float(self.declare_parameter(
            'kd_far_scale', 0.65).value)
        self.kd_near_scale = float(self.declare_parameter(
            'kd_near_scale', 2.0).value)
        self.pos_tau = float(self.declare_parameter(
            'position_filter_tau', 0.03).value)
        self.vel_tau = float(self.declare_parameter(
            'velocity_filter_tau', 0.05).value)

        self.x_axis = str(self.declare_parameter('x_axis', 'pitch').value).lower()
        self.y_axis = str(self.declare_parameter('y_axis', 'roll').value).lower()
        if {self.x_axis, self.y_axis} != {'pitch', 'roll'}:
            raise ValueError("x_axis and y_axis must be 'pitch' and 'roll'")

        self.pitch_sign = float(self.declare_parameter('pitch_sign', 1.0).value)
        self.roll_sign = float(self.declare_parameter('roll_sign', 1.0).value)
        self.throttle_sign = float(self.declare_parameter(
            'throttle_sign', -1.0).value)

        self.gains = {
            'pitch': self._read_gains('pitch_gains', [25.0, 1.5, 45.0]),
            'roll': self._read_gains('roll_gains', [25.0, 1.5, 45.0]),
            'throttle': self._read_gains(
                'throttle_gains', [35.0, 8.0, 55.0]),
        }

        # --- yaw configuration ---------------------------------------
        self.yaw = 0.0
        self.desired_yaw = float(self.declare_parameter(
            'desired_yaw', -0.5).value)
        self.yaw_kp = float(self.declare_parameter('yaw_kp', 1.0).value)
        self.yaw_kd = float(self.declare_parameter('yaw_kd', 0.0).value)
        self.yaw_deadband = float(self.declare_parameter(
            'yaw_deadband', 6.0).value)
        self.yaw_rate = 0.0
        self.last_yaw_time = 0.0

        # --- state ---------------------------------------------------
        self.curr_state = [0.0, 0.0, 0.0]
        self.drone_position = [0.0, 0.0, 0.0]
        self.filtered_state = None
        self.velocity = [0.0, 0.0, 0.0]
        self.error_sum = [0.0, 0.0, 0.0]
        self.desired_state = [0.0, 0.0, 13.0]
        self.last_marker_time = 0.0
        self.last_pid_time = 0.0
        self.dtime = 0

        self.command_roll = BASE_RC
        self.command_pitch = BASE_RC
        self.command_throttle = self.hover_throttle
        self.yaw_command = BASE_RC

        self.cmd = SwiftMsgs()
        self.cmd.rc_roll = int(BASE_RC)
        self.cmd.rc_pitch = int(BASE_RC)
        self.cmd.rc_yaw = int(BASE_RC)
        self.cmd.rc_throttle = int(self.hover_throttle)
        self.cmd.rc_aux4 = 2000

        self.pos_error = Error()

        # --- ROS interfaces -----------------------------------------
        self.command_pub = self.create_publisher(SwiftMsgs, '/drone_command', 10)
        self.pos_error_pub = self.create_publisher(Error, '/pos_error', 10)
        self.heartbeat_pub = self.create_publisher(Header, '/controller_heartbeat', 10)

        self.create_subscription(
            MarkerArray, '/whycode_node/markers', self.whycode_callback, 1)
        self.create_subscription(
            PIDTune, '/pitch_pid', self.pitch_set_pid, 1)
        self.create_subscription(
            PIDTune, '/roll_pid', self.roll_set_pid, 1)
        self.create_subscription(
            PIDTune, '/throttle_pid', self.altitude_set_pid, 1)

        self.action_server = ActionServer(
            self,
            NavToWaypoint,
            'waypoint_navigation',
            execute_callback=self.execute_callback,
            goal_callback=self.goal_callback,
            cancel_callback=self.cancel_callback,
            callback_group=self.action_callback_group,
        )

        self.publish_heartbeat()
        self.create_timer(0.1, self.publish_heartbeat)

        time.sleep(0.5)
        self.arm()

        self.timer = self.create_timer(
            self.sample_time, self.pid,
            callback_group=self.pid_or_lqr_callback_group)

        self.get_logger().info('Waypoint action server ready')

    # ------------------------------------------------------------------
    # Gains / heartbeat / arming
    # ------------------------------------------------------------------
    def _read_gains(self, name, default):
        values = list(self.declare_parameter(name, default).value)
        if len(values) != 3:
            raise ValueError('%s must contain [Kp, Ki, Kd]' % name)
        return [float(v) for v in values]

    def pitch_set_pid(self, tune):
        self.gains['pitch'] = [float(tune.kp), float(tune.ki), float(tune.kd)]

    def roll_set_pid(self, tune):
        self.gains['roll'] = [float(tune.kp), float(tune.ki), float(tune.kd)]

    def altitude_set_pid(self, tune):
        self.gains['throttle'] = [float(tune.kp), float(tune.ki), float(tune.kd)]

    def publish_heartbeat(self):
        if not rclpy.ok():
            return
        hb = Header()
        hb.stamp = self.get_clock().now().to_msg()
        hb.frame_id = 'pico_controller_active'
        self.heartbeat_pub.publish(hb)

    def disarm(self):
        self.cmd.rc_roll = 1000
        self.cmd.rc_yaw = 1000
        self.cmd.rc_pitch = 1000
        self.cmd.rc_throttle = 1000
        self.cmd.rc_aux4 = 1000
        self.command_pub.publish(self.cmd)

    def arm(self):
        self.disarm()
        self.cmd.rc_roll = int(BASE_RC)
        self.cmd.rc_yaw = int(BASE_RC)
        self.cmd.rc_pitch = int(BASE_RC)
        self.cmd.rc_throttle = int(self.hover_throttle)
        self.cmd.rc_aux4 = 2000
        self.command_pub.publish(self.cmd)

    # ------------------------------------------------------------------
    # WhyCode feedback
    # ------------------------------------------------------------------
    def whycode_callback(self, msg):
        if not msg.markers:
            return

        marker = msg.markers[0]
        position = marker.position.position
        pos = [float(position.x), float(position.y), float(position.z)]
        if not all(math.isfinite(v) for v in pos):
            return

        now = time.monotonic()

        if self.filtered_state is None or self.last_marker_time == 0.0:
            self.curr_state = list(pos)
            self.drone_position = list(pos)
            self.filtered_state = list(pos)
            self.velocity = [0.0, 0.0, 0.0]
            self.last_marker_time = now
        else:
            dt = now - self.last_marker_time
            if dt > 1e-6:
                dt = min(dt, 0.5)
                alpha_pos = 1.0 - math.exp(-dt / max(self.pos_tau, 1e-3))
                alpha_vel = 1.0 - math.exp(-dt / max(self.vel_tau, 1e-3))
                for i in range(3):
                    raw_velocity = (pos[i] - self.curr_state[i]) / dt
                    self.velocity[i] += alpha_vel * (
                        raw_velocity - self.velocity[i])
                    self.filtered_state[i] += alpha_pos * (
                        pos[i] - self.filtered_state[i])
                self.curr_state = list(pos)
                self.drone_position = list(pos)
                self.last_marker_time = now

        # Marker orientation is reported in radians; yaw control works in deg.
        yaw = math.degrees(marker.rotation.z)
        if self.last_yaw_time > 0.0:
            dyaw = yaw - self.yaw
            while dyaw > 180.0:
                dyaw -= 360.0
            while dyaw < -180.0:
                dyaw += 360.0
            dt_yaw = max(now - self.last_yaw_time, 1e-3)
            self.yaw_rate += 0.5 * ((dyaw / dt_yaw) - self.yaw_rate)
        self.yaw = yaw
        self.last_yaw_time = now
        self.dtime = msg.header.stamp.sec

    # ------------------------------------------------------------------
    # PID position controller (+ yaw hold)
    # ------------------------------------------------------------------
    def pid(self):
        if not rclpy.ok():
            return
        now = time.monotonic()

        if self.last_marker_time == 0.0 or \
                (now - self.last_marker_time) > self.marker_timeout:
            self.reset_control()
            self.publish_targets(BASE_RC, BASE_RC, self.hover_throttle)
            return

        if self.last_pid_time == 0.0:
            dt = self.sample_time
        else:
            dt = _clamp(now - self.last_pid_time, 1e-3, 0.2)
        self.last_pid_time = now

        with self.state_lock:
            desired = list(self.desired_state)

        z = self.filtered_state[2]

        span = self.airborne_z_start - self.airborne_z_full
        if span <= 1e-6:
            gate = 1.0 if z <= self.airborne_z_start else 0.0
        else:
            gate = (self.airborne_z_start - z) / span
        gate = _clamp(gate, 0.0, 1.0)

        axis_for_index = (self.x_axis, self.y_axis, 'throttle')
        error = [desired[i] - self.filtered_state[i] for i in range(3)]
        output = [0.0, 0.0, 0.0]

        e_h = math.hypot(error[0], error[1])
        blend = _clamp(
            (self.brake_radius - e_h) / max(self.brake_radius, 1e-6), 0.0, 1.0)
        kd_scale = self.kd_far_scale + (
            self.kd_near_scale - self.kd_far_scale) * blend

        for i in range(3):
            kp, ki, kd = self.gains[axis_for_index[i]]
            is_horizontal = i < 2
            if is_horizontal:
                kd = kd * kd_scale

            u = kp * error[i] + ki * self.error_sum[i] - kd * self.velocity[i]

            integrate = True
            if is_horizontal:
                if gate <= 0.0:
                    integrate = False
                elif u >= self.max_tilt and error[i] > 0.0:
                    integrate = False
                elif u <= -self.max_tilt and error[i] < 0.0:
                    integrate = False
            else:
                throttle_preview = self.hover_throttle + self.throttle_sign * u
                rate_sign = self.throttle_sign * error[i]
                if throttle_preview >= self.throttle_max and rate_sign > 0.0:
                    integrate = False
                elif throttle_preview <= self.throttle_min and rate_sign < 0.0:
                    integrate = False

            if integrate:
                self.error_sum[i] += error[i] * dt * (
                    gate if is_horizontal else 1.0)
                self.error_sum[i] = _clamp(
                    self.error_sum[i], -self.integral_limit, self.integral_limit)

            u = kp * error[i] + ki * self.error_sum[i] - kd * self.velocity[i]

            if is_horizontal:
                u = _clamp(gate * u, -self.max_tilt, self.max_tilt)
            output[i] = u

        pitch_input = output[0] if self.x_axis == 'pitch' else output[1]
        roll_input = output[0] if self.x_axis == 'roll' else output[1]

        pitch_target = BASE_RC + self.pitch_sign * pitch_input
        roll_target = BASE_RC + self.roll_sign * roll_input
        throttle_target = self.hover_throttle + self.throttle_sign * output[2]

        if z < (desired[2] - self.altitude_ceiling_margin):
            throttle_target = self.throttle_min
            self.error_sum[2] = min(self.error_sum[2], 0.0)

        self.update_yaw_command()

        self.publish_targets(roll_target, pitch_target, throttle_target)

        self.pos_error.pitch_error = float(
            error[0] if self.x_axis == 'pitch' else error[1])
        self.pos_error.roll_error = float(
            error[0] if self.x_axis == 'roll' else error[1])
        self.pos_error.throttle_error = float(error[2])
        self.pos_error.yaw_error = float(self.desired_yaw - self.yaw)
        self.pos_error_pub.publish(self.pos_error)

    def update_yaw_command(self):
        # The RC yaw channel is rate based (1499/1501 -> +/- max yaw rate), so
        # a proportional term is applied only outside a small deadband.
        yaw_error = self.desired_yaw - self.yaw
        while yaw_error > 180.0:
            yaw_error -= 360.0
        while yaw_error < -180.0:
            yaw_error += 360.0

        rate_ff = -self.yaw_kd * self.yaw_rate
        control = self.yaw_kp * yaw_error + rate_ff

        if abs(yaw_error) <= self.yaw_deadband:
            self.yaw_command = BASE_RC
        elif control > 0.0:
            self.yaw_command = BASE_RC + 1
        else:
            self.yaw_command = BASE_RC - 1

    def reset_control(self):
        self.error_sum = [0.0, 0.0, 0.0]
        self.velocity = [0.0, 0.0, 0.0]
        self.filtered_state = None
        self.last_pid_time = 0.0

    def publish_targets(self, roll, pitch, throttle):
        if not rclpy.ok():
            return
        roll = _clamp(roll, BASE_RC - self.max_tilt, BASE_RC + self.max_tilt)
        pitch = _clamp(pitch, BASE_RC - self.max_tilt, BASE_RC + self.max_tilt)
        throttle = _clamp(throttle, self.throttle_min, self.throttle_max)

        self.command_roll = _slew(self.command_roll, roll, self.max_tilt_step)
        self.command_pitch = _slew(self.command_pitch, pitch, self.max_tilt_step)
        self.command_throttle = _slew(
            self.command_throttle, throttle, self.max_throttle_step)

        self.cmd.rc_roll = int(round(self.command_roll))
        self.cmd.rc_pitch = int(round(self.command_pitch))
        self.cmd.rc_throttle = int(round(self.command_throttle))
        self.cmd.rc_yaw = int(self.yaw_command)
        self.cmd.rc_aux4 = 2000
        self.command_pub.publish(self.cmd)

    # ------------------------------------------------------------------
    # Action server
    # ------------------------------------------------------------------
    def goal_callback(self, goal_request):
        return GoalResponse.ACCEPT

    def cancel_callback(self, goal_handle):
        return CancelResponse.ACCEPT

    def execute_callback(self, goal_handle):

        target = [
            float(goal_handle.request.waypoint.position.x),
            float(goal_handle.request.waypoint.position.y),
            float(goal_handle.request.waypoint.position.z),
        ]

        self.get_logger().info('Executing goal to waypoint: %s' % target)

        with self.state_lock:
            self.desired_state = list(target)
            self.error_sum = [0.0, 0.0, 0.0]
            self.velocity = [0.0, 0.0, 0.0]

        start_time = time.monotonic()
        settle_start = None
        settle_time = 0.0

        feedback_msg = NavToWaypoint.Feedback()

        while rclpy.ok():

            if goal_handle.is_cancel_requested:
                goal_handle.canceled()
                result = NavToWaypoint.Result()
                result.hov_time = int(round(time.monotonic() - start_time))
                return result

            pos = list(self.drone_position)

            in_sphere = (
                abs(pos[0] - target[0]) <= self.whycode_tolerance
                and abs(pos[1] - target[1]) <= self.whycode_tolerance
                and abs(pos[2] - target[2]) <= self.whycode_tolerance
            )

            now = time.monotonic()
            if in_sphere:
                if settle_start is None:
                    settle_start = now
                settle_time = now - settle_start
            else:
                settle_start = None
                settle_time = 0.0

            feedback_msg.current_waypoint.header.stamp.sec = int(settle_time)
            feedback_msg.current_waypoint.header.stamp.nanosec = int(
                (settle_time % 1.0) * 1e9)
            feedback_msg.current_waypoint.header.frame_id = 'whycode'
            feedback_msg.current_waypoint.pose.position.x = pos[0]
            feedback_msg.current_waypoint.pose.position.y = pos[1]
            feedback_msg.current_waypoint.pose.position.z = pos[2]
            feedback_msg.current_waypoint.pose.orientation.w = 1.0
            goal_handle.publish_feedback(feedback_msg)

            if settle_time >= self.hold_time:
                break

            if (now - start_time) > self.goal_timeout:
                self.get_logger().warn(
                    'Timed out waiting to settle at %s' % target)
                goal_handle.abort()
                result = NavToWaypoint.Result()
                result.hov_time = int(round(now - start_time))
                return result

            time.sleep(self.sample_time)

        goal_handle.succeed()

        result = NavToWaypoint.Result()
        result.hov_time = int(round(time.monotonic() - start_time))
        self.get_logger().info(
            'Waypoint %s reached, settle time %d s' % (target, result.hov_time))
        return result


def main(args=None):
    rclpy.init(args=args)

    waypoint_server = WayPointServer()
    executor = MultiThreadedExecutor()
    executor.add_node(waypoint_server)

    try:
        executor.spin()
    except KeyboardInterrupt:
        waypoint_server.get_logger().info('KeyboardInterrupt, shutting down.\n')
    finally:
        waypoint_server.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()

